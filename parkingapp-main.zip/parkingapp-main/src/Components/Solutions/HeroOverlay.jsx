import React from 'react'

export default function HeroOverlay() {
  return (
    <div>HeroOverlay</div>
  )
}
