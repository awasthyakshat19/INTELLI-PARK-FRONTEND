import React from 'react'

export default function SolutionDescription() {
  return (
    <div>SolutionDescription</div>
  )
}
