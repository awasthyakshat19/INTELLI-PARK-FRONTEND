const API_URL = "https://parkingappbackend.onrender.com";
// const API_URL = "http://localhost:1111";

export default API_URL;