import React from 'react'
import { Booking } from '../Components/Booking/Booking'
import Navbar from '../Components/Navbar/Navbar'

export default function BookSlot() {
  return (
    <>
    <Navbar/>
    <Booking/>
    </>
  )
}
