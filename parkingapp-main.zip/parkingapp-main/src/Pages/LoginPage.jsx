import React from 'react'

export default function LoginPage() {
  return (
    <div>LoginPage</div>
  )
}
