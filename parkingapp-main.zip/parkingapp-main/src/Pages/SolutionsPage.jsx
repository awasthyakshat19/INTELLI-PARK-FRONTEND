import React from 'react'
import Navbar from '../Components/Navbar/Navbar'
import Features from '../Components/Solutions/Features'
import Footer from '../Components/Footer/Footer'
import Footer2 from '../Components/Footer/Footer2'

export default function SolutionsPage() {
  return (
   <>
   <Navbar/>
   <br></br>
   <Features/>

   </>
  )
}
